<#
.SYNOPSIS

Run code analysis on a single Oracle database object.

.DESCRIPTION

Copyright (c) 2019 Quest Software Inc. ALL RIGHTS RESERVED.

A simple example that uses Toad DevOps Toolkit to run code analysis on a single database object.

.NOTES

An example request body has been provided which should be customized to your setup.

By default the script fails (sets a non-zero exit code) when any code analysis errors or rule violations are found.

.LINK

https://qsft.github.io/tdt-rest

#>

# By default the server uses a self-signed certificate.
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
# TLS 1.2 is required when communicating wih the server.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

try {
  $Body = @{
    Connection = 'user/password@database'
    Objects = @(@{
      Name = 'name'
      Owner = 'schema'
      Type = 'FUNCTION'
    })
    Options = @{
      ReportName = 'Code Analysis Run Report'
      RuleSet = @{
        Name = 'Top 20'
      }
    }
    Output = @{
      Formats = @('html')
      FolderPath = 'C:\Examples'
    }
  }

  # Convert the PowerShell body to json.
  $Json = $Body | ConvertTo-Json

  'Requesting to run code analysis...'
  $Response = Invoke-WebRequest -Uri 'https://localhost:5000/api/codeanalysis/run' -Method Post -Body $Json -ContentType 'application/json'
  $CodeAnalysisJob = $Response.Content | ConvertFrom-Json

  # Poll the job until the code analysis job has an expected status of 'Finished' or the maximum number of retries has been hit.
  for ($i = 0; $i -lt 10; $i++) {
    'Polling the code analysis status {0}...'-f ($i + 1)

    # Wait a number of seconds between each polling of the status.
    Start-Sleep -S 5
    
    # Get the job's latest status.
    $Response = Invoke-WebRequest -Uri ('https://localhost:5000/api/jobs/{0}' -f $CodeAnalysisJob.Id) -Method Get -ContentType 'application/json'
    $CodeAnalysisJob = $Response.Content | ConvertFrom-Json

    if ($CodeAnalysisJob.Status -eq 'Finished') { break }
  }

  'Gathering results of the code analysis...'
  # Get the job's results once the status has finished.
  $Response = Invoke-WebRequest -Uri ('https://localhost:5000/api/codeanalysis/run/results/{0}' -f $CodeAnalysisJob.Id) -Method Get -ContentType 'application/json'
  $CodeAnalysisResults = $Response.Content | ConvertFrom-Json


  'Code analysis returned {0} errors and {1} rule violations' -f $CodeAnalysisResults.Errors.Count, $CodeAnalysisResults.RuleViolations.Count
  # Return a non-zero exit code when an error or rule violation has occurred.
  if ($CodeAnalysisResults.Errors.Count -gt 0 -or $CodeAnalysisResults.RuleViolations.Count -gt 0) {
    $CodeAnalysisResults.Errors | forEach { $_ }
    $CodeAnalysisResults.RuleViolations | forEach { $_ }
    exit 1
  }
} catch {
  $_.Exception.Message
  exit 1
}