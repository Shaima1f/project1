<#
.SYNOPSIS

List tests for Code Tester unit tests.

.DESCRIPTION

Copyright (c) 2019 Quest Software Inc. ALL RIGHTS RESERVED.

A simple example that uses Toad DevOps Toolkit to list Code Tester tests.

.NOTES

An example request body has been provided which should be customized to your setup.

By default the script fails (sets a non-zero exit code) when an exception occurs.

.LINK

https://qsft.github.io/tdt-rest

#>

# By default the server uses a self-signed certificate.
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
# TLS 1.2 is required when communicating wih the server.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

try {
  $Body = @{
    Connection = 'user/password@database'
    Objects = @(@{
      Name = '%'
      Owner = 'schema'
    })
  }

  # Convert the PowerShell body to json.
  $Json = $Body | ConvertTo-Json

  'List the Code Tester tests...'
  Invoke-WebRequest -Uri 'https://localhost:5000/api/unittests/codetester/tests' -Method Post -Body $Json -ContentType 'application/json'
} catch {
  $_.Exception.Message
  exit 1
}