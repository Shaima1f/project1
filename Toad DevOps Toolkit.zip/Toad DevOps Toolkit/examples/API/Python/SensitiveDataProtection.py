﻿#---------------------------------------------------------------------------
# Copyright (c) 2019 Quest Software
#
# Name          :  SensitiveDataProtection.py
#
# Description   :  Python Example of Toad DevOps Toolkit API (Sensitive Data Protection)
#
# Documentation :  https://qsft.github.io/tdt-rest/
#
# Assumptions   :  'requests' module installed.
#                  'urllib3'  module installed.
#
# Steps         :  1. Get SDP Rules                       (Out: ID)
#                  2. Run SDP                             (Out: Job ID)
#                  3. Run Get Job Status                  (In:  Job ID, Max Attempts, Max Wait Time)
#                  4. Run Get SDP Results                 (In:  Job ID)
#                  5. Run SDP with Custom Rules           (Out: ID)
#                  6. Run Get Job Status                  (In:  Job ID, Max Attempts, Max Wait Time)
#                  7. Run Get SDP Results (Custom Rules)  (In:  Job ID)
#
# Sample Call   :  python {Directory}\SensitiveDataProtection.py
#---------------------------------------------------------------------------
import requests 
import json
import urllib3
import APIUtilities as utl


# Disable Python InsecureRequestWarning
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)



# Variables
URL              = 'https://localhost:5000/api/sensitivedataprotection/search'    # SDP URL
Header           = {"Content-Type" : 'application/json'}                          # Request Header
SourceConnection = 'SOURCE_USER/source_pwd@sourcedb'                              # Source DB credentials
SourceSchema     = 'DEMO'                                                         # Source Schema
ReportName       = 'SDP_Report'                                                   # SDP Report Name
ReportName2      = 'SDP_Report2'                                                  # SDP Report Name (Custom Rules)
OutputPath       = 'C:\Temp'                                                      # Output Path    



def Get_SDPRules():
  try:
     print('Running: Get Sensitive Data Protection Rules...')  
     
     RulesURL = URL + '/rules'
  
     # Run Get Results by ID
     utl.LogRequestInfo(RulesURL, Header)
     response = requests.get(RulesURL, headers=Header, verify=False)

     # Process Response 
     utl.ProcessResponse(response, None)
       
     
  except:
     print('Get_SDPRules - Unexpected Error')
    
    
def Run_SDP():
  try: 
     print('Running: Sensitive Data Protection...')
     
     # Set Payload with Variable Values
     Payload = {}
     Payload["connection"]    = "%s" %SourceConnection
     Payload["schemas"]       = ["%s" %SourceSchema]
     Payload["options"]       = {"reportName"  : "%s" %ReportName}
     Payload["output"]        = {"folderPath"  : "%s" %OutputPath,
                                 "formats"     : ["html", "json", "xls", "xml"]}
     Payload                  = json.dumps(Payload)
  
     # Run POST to SDP
     utl.LogRequestInfo(URL, Header, Payload)    
     response = requests.post(URL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     id = utl.ProcessResponse(response, 'id')
        
     return id
            
  except:
     print('Run_SDP - Unexpected Error')     
  
     
def Run_SDP_CustomRules():
  try:
     print('Running: Get Sensitive Data Protection Custom Rules...') 
     
     # Set Payload with Variable Values
     Payload = {}
     Payload["connection"]    = "%s" %SourceConnection
     Payload["schemas"]       = ["%s" %SourceSchema]
     Payload["options"]       = {"reportName"  : "%s" %ReportName2}
     Payload["rules"]         = {"disable"     : ["1100"],
                                 "custom"      : [{"name"       : "SDPTestRule",
                                                   "type"       : "ColumnName",
                                                   "expression" : "^(DOB)$",
                                                   "enabled"    : True}
                                                 ]}
     Payload["output"]        = {"folderPath"  : "%s" %OutputPath,
                                 "formats"     : ["html", "json", "xls", "xml"]}
     Payload                  = json.dumps(Payload)
  
   
     # Run POST to SDP
     utl.LogRequestInfo(URL, Header, Payload)    
     response = requests.post(URL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     id = utl.ProcessResponse(response, 'id')
        
     return id
            
  except:
     print('Run_SDP_CustomRules - Unexpected Error')     
     
     
def Get_SDPResults(id):
  try:
     print('')
     print('--------------------------------------------------')
     print('Running: Get Sensitive Data Protection Results (id = ' + str(id) + ')...')
  
     # Set Variables
     ResultsURL = URL + '/results/' + str(id)
     
     # Run Get Results by ID 
     utl.LogRequestInfo(ResultsURL, Header)
     response = requests.get(ResultsURL, headers=Header, verify=False)

     # Process Response 
     utl.ProcessResponse(response, None)

  except:
     print('Get_SDPResults - Unexpected Error')

  finally:  
    print('--------------------------------------------------') 


#---------------------------------------------------------------------------
# Main Process Calls
#---------------------------------------------------------------------------

# Print Header
print('--------------------------------------------------')
print('     Sensitive Data Protection Example            ')
print('--------------------------------------------------')


# Step 1. Get SDP Rules - returns ID 
id = Get_SDPRules()

# Step 2. Run SDP - returns Job ID
id = Run_SDP()

# Step 3. Run Get Job Status - returns job status; will retry until 'Finished' status or Max Retries (5); Wait 5 seconds between retries
jobstatus = utl.Get_JobStatus(id, 5, 5) 
   
# Step 4. Run Get SDP Results - passes in Job ID
Get_SDPResults(id)

# Step 5. Run SDP with Custom Rules - returns ID
id = Run_SDP_CustomRules()

# Step 6. Run Get Job Status - returns job status; will retry until 'Finished' status or Max Retries (5); Wait 5 seconds between retries 
jobstatus = utl.Get_JobStatus(id, 5, 5) 

# Step 7. Run Get SDP Results - passes in Job ID
Get_SDPResults(id)
    
     
     
