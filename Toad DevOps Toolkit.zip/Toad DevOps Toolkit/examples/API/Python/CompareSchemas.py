﻿#---------------------------------------------------------------------------
# Copyright (c) 2019 Quest Software
#
# Name          :  CompareSchemas.py
#
# Description   :  Python Example of Toad DevOps Toolkit API (Compare Schemas)
#
# Documentation :  https://qsft.github.io/tdt-rest/
#
# Assumptions   :  'requests' module installed.
#                  'urllib3'  module installed.
#
# Steps         :  1. Run Compare Schemas using Connection  (Out: Job ID)
#                  2. Run Get Job Status                    (In:  Job ID, Max Attempts, Max Wait Time)
#                  3. Run Get Compare Schemas Results       (In:  Job ID)
#                  4. Run Compare Schemas using Snapshots   (Out: Job ID)
#                  5. Run Get Job Status                    (In:  Job ID, Max Attempts, Max Wait Time)
#                  6. Run Get Compare Schemas Results       (In:  Job ID)
#
# Sample Call   :  python {Directory}\CompareSchemas.py
#---------------------------------------------------------------------------
import requests 
import json
import urllib3
import APIUtilities as utl


# Disable Python InsecureRequestWarning
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)



# Variables
URL                    = 'https://localhost:5000/api/schemas/compare'               # Compare Schemas Run URL            
Header                 = {"Content-Type" : 'application/json'}                      # JSON Header 
SourceConnection       = 'SOURCE_USER/source_pwd@sourcedb'                          # Source DB credentials
SourceSchema           = 'DEMO'                                                     # Source Schema
TargetConnection       = 'TARGET_USER/target_pwd@targetdb'                          # Target DB credentials
TargetSchema           = 'DEMO'                                                     # Target Schema
DifferenceDetailsHTML  = 'C:\Temp\CompareSchemas_DiffDetails.html'                  # Difference Details Report (HTML)
DifferenceDetailsCSV   = 'C:\Temp\CompareSchemas_DiffDetails.csv'                   # Difference Details Report (CSV)
DifferenceDetailsTXT   = 'C:\Temp\CompareSchemas_DiffDetails.txt'                   # Difference Details Report (TXT)
DifferenceDetailsHTML2 = 'C:\Temp\CompareSchemas_DiffDetails2.html'                 # Difference Details Report (HTML) - Snapshot
DifferenceDetailsCSV2  = 'C:\Temp\CompareSchemas_DiffDetails2.csv'                  # Difference Details Report (CSV)  - Snapshot
DifferenceDetailsTXT2  = 'C:\Temp\CompareSchemas_DiffDetails2.txt'                  # Difference Details Report (TXT)  - Snapshot
DifferenceSummary      = 'C:\Temp\CompareSchemas_DiffSummary.html'                  # Difference Summary Report (HTML)
DifferenceSummary2     = 'C:\Temp\CompareSchemas_DiffSummary2.htm'                  # Difference Summary Report (HTML) - Snapshot
syncScript             = 'C:\Temp\CompareSchemas_SyncScript.sql'                    # Sync Script
syncScript2            = 'C:\Temp\CompareSchemas_SyncScript2.sql'                   # Sync Script - Snapshot
SourceSnapshot         = 'C:\Temp\CompareSchemas_SourceSnapshot.json'               # Source Snapshot
TargetSnapshot         = 'C:\Temp\CompareSchemas_TargetSnapshot.json'               # Target Snapshot

  

def Run_CompareSchemas():
  try:
     print('Running: Compare Schemas (Connection)...')
     
     # Set Payload with Variable Values
     Payload = {}
     Payload["source"]        = {"connection"        : "%s" %SourceConnection,
                                 "schema"            : "%s" %SourceSchema}
     Payload["target"]        = {"connection"        : "%s" %TargetConnection,
                                 "schema"            : "%s" %TargetSchema} 
     Payload["compare"]       = {"objectTypes"       : {"all" : True}}
     Payload["output"]        = {"sourceSnapshot"    : {"filePath"  : "%s" %SourceSnapshot},
                                 "targetSnapshot"    : {"filePath"  : "%s" %TargetSnapshot},
                                 "syncScript"        : {"filePath"  : "%s" %syncScript},
                                 "differenceDetails" : [{"filePath" : "%s" %DifferenceDetailsHTML}, 
                                                        {"filePath" : "%s" %DifferenceDetailsCSV},
                                                        {"filePath" : "%s" %DifferenceDetailsTXT}
                                                       ]}
     Payload["options"]       = {"storageClauses"    : {"all" : True}}     
     Payload                  = json.dumps(Payload)

       
     # Run POST to Compare Schemas
     utl.LogRequestInfo(URL, Header, Payload)    
     response = requests.post(URL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     id = utl.ProcessResponse(response, 'id')
        
     return id

     
  except:
     print('Run_CompareSchemas - Unexpected Error')     

     
def Run_CompareSchemas_Snapshots():
  try:
     print('Running: Compare Schemas (Snapshots)...')
     
     # Set Payload with Variable Values
     Payload = {}
     Payload["source"]        = {"connection"        : "%s" %SourceConnection,
                                 "schema"            : "%s" %SourceSchema,
                                 "snapshot"          : {"filePath" : "%s" %SourceSnapshot}}
     Payload["target"]        = {"connection"        : "%s" %TargetConnection,
                                 "schema"            : "%s" %TargetSchema,
                                 "snapshot"          : {"filePath" : "%s" %TargetSnapshot}}  
     Payload["compare"]       = {"objectTypes"       : {"all" : True}}
     Payload["output"]        = {"syncScript"        : {"filePath" : "%s" %syncScript2},
                                 "differenceDetails" : [{"filePath" : "%s" %DifferenceDetailsHTML2}, 
                                                        {"filePath" : "%s" %DifferenceDetailsCSV2},
                                                        {"filePath" : "%s" %DifferenceDetailsTXT2}
                                                       ]}
     Payload["options"]       = {"storageClauses"    : {"all" : True}}     
     Payload                  = json.dumps(Payload)

       
     # Run POST to Compare Schemas
     utl.LogRequestInfo(URL, Header, Payload)    
     response = requests.post(URL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     id = utl.ProcessResponse(response, 'id')
        
     return id

     
  except:
     print('Run_CompareSchemas_Snapshots - Unexpected Error')   
     
                     
def Get_CompareSchemasResults(id):
  try:
     print('')
     print('--------------------------------------------------')
     print('Running: Get Script Sesults (id = ' + str(id) + ')...')
     
     # Set Variables
     ResultsURL = URL + '/results/' + str(id)
     
     # Run Get Compare Database Results by ID
     utl.LogRequestInfo(ResultsURL, Header)
     response = requests.get(ResultsURL, headers=Header, verify=False)

     # Process Response 
     utl.ProcessResponse(response, None)
     
     
  except:
     print('Get_CompareSchemasResults - Unexpected Error')

  finally:  
    print('--------------------------------------------------') 



#---------------------------------------------------------------------------
# Main Process Calls
#---------------------------------------------------------------------------

# Print Header
print('--------------------------------------------------')
print('          Compare Schemas Example                  ')
print('--------------------------------------------------')


# Step 1. Run Compare Schemas (Connection) - returns Job ID
id = Run_CompareSchemas()

# Step 2. Run Get Job Status  (Connection) - returns job status; will retry until 'Finished' status or Max Retries (10); Wait 10 seconds between retries
jobstatus = utl.Get_JobStatus(id, 10, 10) 
   
# Step 3. Run Get Compare Schemas Results  (Connection) - passes in Job ID
Get_CompareSchemasResults(id)  

# Step 4. Run Compare Schemas (Snapshots) - returns Job ID 
id = Run_CompareSchemas_Snapshots()

# Step 5. Run Get Job Status (Snapshots) - returns job status; will retry until 'Finished' status or Max Retries (10); Wait 10 seconds between retries
jobstatus = utl.Get_JobStatus(id, 10, 10)

# Step 6. Run Get Compare Schemas Results (Snapshots) - passes in Job ID  
Get_CompareSchemasResults(id)  

     