﻿#---------------------------------------------------------------------------
# Copyright (c) 2019 Quest Software
#
# Name          :  APIUtilities.py
#
# Description   :  Python Example of Toad DevOps Toolkit API (API Utilities)
#
# Documentation :  https://qsft.github.io/tdt-rest/
#
# Assumptions   :  'requests' module installed.
#
# Sample Call   :  python {Directory}\APIUtilities.py
#---------------------------------------------------------------------------
import requests 
import json
import time


# Variables
gURL    = 'https://localhost:5000/api'
gHeader = {"Content-Type" : "application/json"}



# LogRequestInfo - Sends Request information to Log
def LogRequestInfo(URL, Header, Payload=None):
  try:
     print('   URL: ' + URL)
     print('   Header: '+ json.dumps(Header))
     print('   Payload: ' + str(Payload))
     
  except:
     print('LogRequestInfo - Unexpected Error')
   

    
# ProcessResponse - Parses Rest Response.  Used for Expected Good Responses (200, 201, 202)   
def ProcessResponse(response, returnval=None):
  try:
    retval = None
   
    print('   Response Code: ' + str(response.status_code))

    if response.status_code in (200, 201, 202):
       print('   Response JSON: ' + response.text)
       
       # Convert response into a Python Dictionary
       responsedict = json.loads(response.text) 
     
       # Log keys and values from dictionary
       if type(responsedict) is dict:
          for dictkey, dictvalue in responsedict.items():
              #print(str(dictkey) + ' : ' + str(dictvalue))
      
              if dictkey == returnval:
                 retval = dictvalue 
            
    else:
        print(str(response.status_code) + ' Error: ' + response.text)   
    
    
  except:
    print('Error - Unable to parse response: Response: ' + response.text)
    retval = 'Error' 
    
  finally:  
    return retval
    
   
    
# Get_JobStatus - Gets a jobs status by ID.  Sets Max Attempts and Wait Time between checks.     
def Get_JobStatus(id, maxattempts=5, waittime=5):
  try:
  
     print('')
     print('--------------------------------------------------')
     print('Running: Get Job Status...')
     
     
     jobstatus   = None     
     attempts    = 0
     
     # Set URL
     URL = gURL + '/jobs/' + str(id)

     # Run Get Job Status
     LogRequestInfo(URL, gHeader)
  
     while jobstatus not in ('Finished', 'Error', 'MaxAttemptsExceeded'):
         attempts += 1
         response = requests.get(URL, headers=gHeader, verify=False)

         # Process Response 
         jobstatus = ProcessResponse(response, 'status')
         
         if jobstatus == 'Finished':
            break
         else:
            print('   Retry Attempt ' + str(attempts) + ' of ' + str(maxattempts) + ' - Job Status: ' + str(jobstatus))
            time.sleep(waittime)
         
         
         if attempts >= maxattempts:
            jobstatus = 'MaxAttemptsExceeded'
            break  
        
   
     return jobstatus

  except:
     print('Get_JobStatus - Unexpected Error')     