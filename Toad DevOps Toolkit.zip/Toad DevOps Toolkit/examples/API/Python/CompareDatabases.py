﻿#---------------------------------------------------------------------------
# Copyright (c) 2019 Quest Software
#
# Name          :  CompareDatabases.py
#
# Description   :  Python Example of Toad DevOps Toolkit API (Compare Databases)
#
# Documentation :  https://qsft.github.io/tdt-rest/
#
# Assumptions   :  'requests' module installed.
#                  'urllib3'  module installed.
#
# Steps         :  1. Run Compare Databases using Connection  (Out: Job ID)
#                  2. Run Get Job Status                      (In:  Job ID, Max Attempts, Max Wait Time)
#                  3. Run Get Compare Databases Results       (In:  Job ID)
#                  4. Run Compare Databases using Snapshots   (Out: Job ID)
#                  5. Run Get Job Status                      (In:  Job ID, Max Attempts, Max Wait Time)
#                  6. Run Get Compare Databases Results       (In:  Job ID)
#
# Sample Call   :  python {Directory}\CompareDatabases.py
#---------------------------------------------------------------------------
import requests 
import json
import urllib3
import APIUtilities as utl


# Disable Python InsecureRequestWarning
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)



# Variables
URL                = 'https://localhost:5000/api/databases/compare'               # Compare Databases Run URL
Header             = {"Content-Type" : 'application/json'}                        # JSON Header
SourceConnection   = 'SOURCE_USER/source_pwd@sourcedb'                            # Source DB credentials
TargetConnection   = 'TARGET_USER/target_pwd@targetdb'                            # Target DB credentials
DifferenceDetails  = 'C:\Temp\CompareDatabases_DiffDetails.txt'                   # Difference Details Report
DifferenceSummary  = 'C:\Temp\CompareDatabases_DiffSummary.htm'                   # Difference Summary Report
syncScript         = 'C:\Temp\CompareDatabases_SyncScript.sql'                    # Sync Script
DifferenceDetails2 = 'C:\Temp\CompareDatabases_DiffDetails2.txt'                  # Difference Details Report (from Snapshots)
DifferenceSummary2 = 'C:\Temp\CompareDatabases_DiffSummary2.htm'                  # Difference Summary Report (from Snapshots)
syncScript2        = 'C:\Temp\CompareDatabases_SyncScript2.sql'                   # Sync Script (from Snapshots)
SourceSnapshot     = 'C:\Temp\CompareDatabases_SourceSnapshot.xml'                # Source Snapshot 
TargetSnapshot     = 'C:\Temp\CompareDatabases_TargetSnapshot.xml'                # Target Snapshot
  

def Run_CompareDatabases():
  try:
     print('Running: Compare Databases (Connection)...')
     
     # Set Payload with Variable Values
     Payload = {}
     Payload["source"]  = {"connection"  : "%s" %SourceConnection}
     Payload["target"]  = {"connection"  : "%s" %TargetConnection} 
     Payload["compare"] = {"objectTypes" : {"all" : True}}
     Payload["output"]  = {"differenceDetails" : {"filePath" : "%s" %DifferenceDetails},
                           "differenceSummary" : {"filePath" : "%s" %DifferenceSummary},
                           "sourceSnapshot"    : {"filePath" : "%s" %SourceSnapshot},
                           "targetSnapshot"    : {"filePath" : "%s" %TargetSnapshot},
                           "syncScript"        : {"filePath" : "%s" %syncScript}
                          }     
     Payload            = json.dumps(Payload)

       
     # Run POST to Compare Databases
     utl.LogRequestInfo(URL, Header, Payload)    
     response = requests.post(URL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     id = utl.ProcessResponse(response, 'id')
        
     return id

     
  except:
     print('Run_CompareDatabases - Unexpected Error')     

     
def Run_CompareDatabases_Snapshots():
  try:
     print('Running: Compare Databases (Snapshots)...')
     
     # Set Payload with Variable Values
     Payload = {}
     Payload["source"]  = {"snapshot"          : {"filePath" : "%s" %SourceSnapshot}}
     Payload["target"]  = {"snapshot"          : {"filePath" : "%s" %TargetSnapshot}} 
     Payload["compare"] = {"objectTypes"       : {"all" : True}}
     Payload["output"]  = {"differenceDetails" : {"filePath" : "%s" %DifferenceDetails2},
                           "differenceSummary" : {"filePath" : "%s" %DifferenceSummary2},
                           "syncScript"        : {"filePath" : "%s" %syncScript2}}     
     Payload            = json.dumps(Payload)

       
     # Run POST to Compare Databases
     utl.LogRequestInfo(URL, Header, Payload)    
     response = requests.post(URL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     id = utl.ProcessResponse(response, 'id')
        
     return id

     
  except:
     print('Run_CompareDatabases_Snapshots - Unexpected Error')   
     
                     
def Get_CompareDatabasesResults(id):
  try:
     print('')
     print('--------------------------------------------------')
     print('Running: Get Script Sesults (id = ' + str(id) + ')...')
     
     # Set Variables
     ResultsURL = URL + '/results/' + str(id)
     
     # Run Get Compare Database Results by ID
     utl.LogRequestInfo(ResultsURL, Header)
     response = requests.get(ResultsURL, headers=Header, verify=False)

     # Process Response 
     utl.ProcessResponse(response, None)
     
     
  except:
     print('Get_CompareDatabasesResults - Unexpected Error')

  finally:  
    print('--------------------------------------------------') 



#---------------------------------------------------------------------------
# Main Process Calls
#---------------------------------------------------------------------------

# Print Header
print('--------------------------------------------------')
print('          Compare Databases Example                  ')
print('--------------------------------------------------')


# Step 1. Run Compare Databases (Connection) - returns Job ID
id = Run_CompareDatabases()

# Step 2. Run Get Job Status  (Connection) - returns job status; will retry until 'Finished' status or Max Retries (10); Wait 10 seconds between retries
jobstatus = utl.Get_JobStatus(id, 10, 10) 
   
# Step 3. Run Get Compare Databases Results  (Connection) - passes in Job ID
Get_CompareDatabasesResults(id)  

# Step 4. Run Compare Databases (Snapshots) - returns Job ID 
id = Run_CompareDatabases_Snapshots()

# Step 5. Run Get Job Status (Snapshots) - returns job status; will retry until 'Finished' status or Max Retries (10); Wait 10 seconds between retries
jobstatus = utl.Get_JobStatus(id, 10, 10)

# Step 6. Run Get Compare Databases Results (Snapshots) - passes in Job ID  
Get_CompareDatabasesResults(id)  
      
     
     
