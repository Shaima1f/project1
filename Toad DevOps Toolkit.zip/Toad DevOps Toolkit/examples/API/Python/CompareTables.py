﻿#---------------------------------------------------------------------------
# Copyright (c) 2019 Quest Software
#
# Name          :  CompareTables.py
#
# Description   :  Python Example of Toad DevOps Toolkit API (Compare Tables)
#
# Documentation :  https://qsft.github.io/tdt-rest/
#
# Assumptions   :  'requests' module installed.
#                  'urllib3'  module installed.
#
# Steps         :  1. Run Compare Tables - Immediate       (Out: Job ID)
#                  2. Run Get Job Status                   (In:  Job ID, Max Attempts, Max Wait Time)
#                  3. Run Get Compare Tables Results       (In:  Job ID)
#                  4. Run Compare Tables - Script          (Out: Job ID)  
#                  5. Run Get Job Status                   (In:  Job ID, Max Attempts, Max Wait Time)
#                  6. Run Get Compare Tables Results       (In:  Job ID)
#                  7. Run Compare Tables - Scripts         (Out: Job ID)  
#                  8. Run Get Job Status                   (In:  Job ID, Max Attempts, Max Wait Time)
#                  9. Run Get Compare Tables Results       (In:  Job ID)
#
# Sample Call   :  python {Directory}\CompareTables.py
#---------------------------------------------------------------------------
import requests 
import json
import urllib3
import APIUtilities as utl


# Disable Python InsecureRequestWarning
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)



# Variables
URL              = 'https://localhost:5000/api/tables/compare'               # Compare Tables Run URL
Header           = {"Content-Type" : 'application/json'}                     # JSON Header 
SourceConnection = 'SOURCE_USER/source_pwd@sourcedb'                         # Source DB credentials
SourceSchema     = 'DEMO'                                                    # Source Schema
TargetConnection = 'TARGET_USER/target_pwd@targetdb'                         # Target DB credentials
TargetSchema     = 'DEMO'                                                    # Target Schema
TableMappings    = 'DEMO_TABLE=DEMO_TABLE'                                   # Table Mappings
syncFolder       = 'C:\Temp'                                                 # Sync Folder
syncScript       = 'C:\Temp\CompareTables_SyncScript.sql'                    # Sync Script
             
  

def Run_CompareTables_immediate():
  try:
     print('Running: Compare Tables (Immediate)...')
     
     # Set Payload with Variable Values
     Payload = {}
     Payload["source"]        = {"connection" : "%s" %SourceConnection,
                                 "schema"     : "%s" %SourceSchema}
     Payload["target"]        = {"connection" : "%s" %TargetConnection,
                                 "schema"     : "%s" %TargetSchema}
     Payload["tableMappings"] = "%s" %TableMappings 
     Payload["options"]       = {"sync"       : "immediate"} 
     Payload["output"]        = {"syncScripts": {"folderPath" : "%s" %syncScript}}                              
     Payload                  = json.dumps(Payload)

       
     # Run POST to Compare Tables
     utl.LogRequestInfo(URL, Header, Payload)    
     response = requests.post(URL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     id = utl.ProcessResponse(response, 'id')
        
     return id

     
  except:
     print('Run_CompareTables_immediate - Unexpected Error')     


def Run_CompareTables_script():
  try:
     print('Running: Compare Tables (Script)...')
     
     # Set Payload with Variable Values
     Payload = {}
     Payload["source"]        = {"connection" : "%s" %SourceConnection,
                                 "schema"     : "%s" %SourceSchema}
     Payload["target"]        = {"connection" : "%s" %TargetConnection,
                                 "schema"     : "%s" %TargetSchema}
     Payload["tableMappings"] = "%s" %TableMappings 
     Payload["options"]       = {"sync"       : "script"} 
     Payload["output"]        = {"syncScript" : {"filePath" : "%s" %syncScript}}                              
     Payload                  = json.dumps(Payload)

       
     # Run POST to Compare Tables
     utl.LogRequestInfo(URL, Header, Payload)    
     response = requests.post(URL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     id = utl.ProcessResponse(response, 'id')
        
     return id

     
  except:
     print('Run_CompareTables_script - Unexpected Error') 


def Run_CompareTables_scripts():
  try:
     print('Running: Compare Tables (Scripts)...')
     
     # Set Payload with Variable Values
     Payload = {}
     Payload["source"]        = {"connection" : "%s" %SourceConnection,
                                 "schema"     : "%s" %SourceSchema}
     Payload["target"]        = {"connection" : "%s" %TargetConnection,
                                 "schema"     : "%s" %TargetSchema}
     Payload["tableMappings"] = "%s" %TableMappings 
     Payload["options"]       = {"sync"       : "scripts"} 
     Payload["output"]        = {"syncScripts": {"folderPath" : "%s" %syncFolder}}                              
     Payload                  = json.dumps(Payload)

       
     # Run POST to Compare Tables
     utl.LogRequestInfo(URL, Header, Payload)    
     response = requests.post(URL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     id = utl.ProcessResponse(response, 'id')
        
     return id

     
  except:
     print('Run_CompareTables_scripts - Unexpected Error')     
     
     
def Get_CompareTablesResults(id):
  try:
     print('')
     print('--------------------------------------------------')
     print('Running: Get Script Results (id = ' + str(id) + ')...')
     
     # Set Variables
     ResultsURL = URL + '/results/' + str(id)
     
     # Run Get Compare Database Results by ID
     utl.LogRequestInfo(ResultsURL, Header)
     response = requests.get(ResultsURL, headers=Header, verify=False)

     # Process Response 
     utl.ProcessResponse(response, None)
     
     
  except:
     print('Get_CompareTablesResults - Unexpected Error')

  finally:  
    print('--------------------------------------------------') 



#---------------------------------------------------------------------------
# Main Process Calls
#---------------------------------------------------------------------------

# Print Header
print('--------------------------------------------------')
print('          Compare Tables Example                  ')
print('--------------------------------------------------')


# Step 1. Run Compare Tables (Immediate) - returns Job ID
id = Run_CompareTables_immediate()

# Step 2. Run Get Job Status (Immediate) - returns job status; will retry until 'Finished' status or Max Retries (5); Wait 5 seconds between retries
jobstatus = utl.Get_JobStatus(id, 5, 5) 
   
# Step 3. Run Get Compare Tables Results (Immediate) - passes in Job ID
Get_CompareTablesResults(id)  

# Step 4. Run Compare Tables (Script) - returns Job ID 
id = Run_CompareTables_script()

# Step 5. Run Get Job Status (Script) - returns job status; will retry until 'Finished' status or Max Retries (5); Wait 5 seconds between retries
jobstatus = utl.Get_JobStatus(id, 5, 5)

# Step 6. Run Get Compare Tables Results (Script) - passes in Job ID  
Get_CompareTablesResults(id)  

# Step 7. Run Compare Tables (Scripts) - returns Job ID 
id = Run_CompareTables_scripts()

# Step 8. Run Get Job Status (Scripts) - returns job status; will retry until 'Finished' status or Max Retries (5); Wait 5 seconds between retries
jobstatus = utl.Get_JobStatus(id, 5, 5)

# Step 9. Run Get Compare Tables Results (Scripts) - passes in Job ID  
Get_CompareTablesResults(id) 

        
