﻿#-------------------------------------------------------------------------------------------------------------------------------
# Copyright (c) 2017 Quest Software
#
# Name: CompareTables.ps1
#
# Description :  Compares a Source and Target table and gets Output.
#-------------------------------------------------------------------------------------------------------------------------------


# Start TDT
$TDT = New-Object -ComObject 'Toad.ToadAutoObject'                                    # Start TDT    


try {
     # Make Connections to Source and Target
     $Source = $TDT.Connections.NewConnection('source_user/source_pwd@sourcedb')      # Source DB credentials
     $Target = $TDT.Connections.NewConnection('target_user/target_pwd@targetdb')      # Target DB credentials


     # Set Schema Compare Parameters
     $TDT.CompareMultipleTables.SourceConnection       = 'source_schema@sourcedb'     # Set Source Connection info
     $TDT.CompareMultipleTables.SourceSchema           = 'source_schema'              # Set Source Schema
     $TDT.CompareMultipleTables.TargetConnection       = 'target_schema@targetdb'     # Set Target Connection info
     $TDT.CompareMultipleTables.TargetSchema           = 'target_schema'              # Set Target Schema
     $TDT.CompareMultipleTables.TableMappings.Add('DEMO_TABLE=DEMO_TABLE')            # Set Table names to compare
     $TDT.CompareMultipleTables.SyncFolder              = "C:\Temp"                   # Set Output Folder
     $TDT.CompareMultipleTables.SyncMode                = 1                           # Set Sync Mode


     # Running Schema Compare
     $TDT.CompareMultipleTables.Execute()
    }


finally {
         $TDT.Quit()                                                                  # Stop TDT
        }