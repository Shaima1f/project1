﻿#-------------------------------------------------------------------------------------------------------------------------------
# Copyright (c) 2017 Quest Software
#
# Name: CompareSchemas.ps1
#
# Description :  Compares a Source and Target schema and gets Output.
#-------------------------------------------------------------------------------------------------------------------------------


$TDT = New-Object -ComObject 'Toad.ToadAutoObject'                                # Start TDT  


try {
     # Make Connections to Source and Target Databases
     $Source = $TDT.Connections.NewConnection('source_user/source_pwd@sourcedb')  # Source DB credentials
     $Target = $TDT.Connections.NewConnection('target_user/target_pwd@targetdb')  # Target DB credentials


     # Set Schema Compare Parameters
     $TDT.CompareSchemas.StorageOptions.IncludeAll()                              # Include all Storage Options
     $TDT.CompareSchemas.TypeOptions.IncludeAll()                                 # Include all Type Options
     $TDT.CompareSchemas.ObjectTypes.IncludeAll()                                 # Include all Object Types


     # Setting Source Connection Information
     $TDT.CompareSchemas.Source.Connection = $Source                              # Set Source Connection info      
     $TDT.CompareSchemas.Source.Schema     = 'source_schema'                      # Set Source Schema


     # Setting Target Connection Information
     $TDT.CompareSchemas.Target.Connection = $Target                              # Set Target Connection info
     $TDT.CompareSchemas.Target.Schema     = 'target_schema'                      # Set Target Schema


     # Run Schema Compare
     $TDT.CompareSchemas.Execute()


     # Get CompareSchema output scripts
     $Script = $TDT.CompareSchemas.GetScript()                                    # Get Output and save to $Script variable
 
    }

finally {
         $TDT.Quit()                                                              # Stop TDT
        }

