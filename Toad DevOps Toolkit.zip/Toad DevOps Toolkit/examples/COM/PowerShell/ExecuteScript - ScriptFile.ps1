﻿#-------------------------------------------------------------------------------------------------------------------------------
# Copyright (c) 2017 Quest Software
#
# Name        :  ExecuteScript - ScriptFile.ps1
# Description :  Runs a SQL file and outputs the result to screen.
#-------------------------------------------------------------------------------------------------------------------------------


# Start TDT
$TDT = New-Object -ComObject 'Toad.ToadAutoObject'                                # Start TDT  


try {
     # Make Connections to Source Database
     $Source = $TDT.Connections.NewConnection('source_user/source_pwd@sourcedb')  # Source DB credentials

     # Setting Script Parameters (for Input SQL file)
     $Script               = $TDT.Scripts.Add()                                   # Set $Script Variable for Add function
     $Script.Connection    = $Source                                              # Set Source connection info
     $Script.IncludeOutput = $TRUE                                                # Set Include Output parameter to True
     $Script.MaxRows       = 100                                                  # Set Max Rows to display to 100
     $Script.InputFile     = "C:\Temp\myquery.sql"                                # Input SQL File


     # Run Script Execute
     $Script.Execute()


     # Output results to variable
     $ScriptOutput = $Script.OutputText                                           # Output results to a Variable
    }

finally {
         $TDT.Quit()                                                              # Stop TDT
        }