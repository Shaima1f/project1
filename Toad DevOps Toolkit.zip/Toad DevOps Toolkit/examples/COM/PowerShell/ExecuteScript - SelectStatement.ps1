﻿#-------------------------------------------------------------------------------------------------------------------------------
# Copyright (c) 2017 Quest Software
#
# Name        :  ExecuteScript - SelectStatement.ps1
# Description :  Runs a select statement and outputs the result to screen.
#-------------------------------------------------------------------------------------------------------------------------------


# Start TDT
$TDT = New-Object -ComObject 'Toad.ToadAutoObject'                                # Start TDT  


try {
     # Make Connection to Source Database
     $Source = $TDT.Connections.NewConnection('source_user/source_pwd@sourcedb')  # Source DB credentials

     # Setting Script Parameters (for hard coded select statement)
     $Script               = $TDT.Scripts.Add()                                   # Set $Script Variable for Add function
     $Script.Connection    = $Source                                              # Set Source connection info
     $Script.IncludeOutput = $TRUE                                                # Set Include Output parameter to True
     $Script.MaxRows       = 10                                                   # Set Max Rows to display to 10
     $Script.InputText     = "select 'Hello World!' from dual"                    # Select Statement to run


     # Run Script Execute
     $Script.Execute()


     # Output results to screen
     $ScriptOutput = $Script.OutputText                                           # Get Output Text from query
     Write-Host $ScriptOutput                                                     # Output to screen
    }

finally {
         $TDT.Quit()                                                              # Stop TDT
        }