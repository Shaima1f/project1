#-----------------------------------------------------------------
# Copyright (c) 2019 Quest Software
#
# Name: SensitiveDataSearch.ps1
# Description: Demonstrates various Sensitive Data Search calls.           
#-----------------------------------------------------------------


# Initialize TDT Instance
$TDT = New-Object -ComObject 'Toad.ToadAutoObject' 			# Start TDT   

try {

   # Check if TDT was started
   if ($TDT) {
       # Make a Connection
       $NewConnection = $TDT.Connections.NewConnection('user/pwd@db')	# Source DB credentials
           
       # If Connection Made - set parameters 
       if ($NewConnection) {
           $TDT.SensitiveDataSearch.Connection = $NewConnection		# Assign connection          
		   
	   # Set schemas in which to search
	   $TDT.SensitiveDataSearch.Schemas.Add('HR')
	   $TDT.SensitiveDataSearch.Schemas.Add('SCOTT')
		   
	   # Set output report location and formats
           $TDT.SensitiveDataSearch.ReportName                = 'SDS_Report'
           $TDT.SensitiveDataSearch.OutputFolder              = 'c:\output'
           $TDT.SensitiveDataSearch.ReportFormats.IncludeHTML = $TRUE
           $TDT.SensitiveDataSearch.ReportFormats.IncludeJSON = $TRUE
           $TDT.SensitiveDataSearch.ReportFormats.IncludeXLS  = $TRUE
           $TDT.SensitiveDataSearch.ReportFormats.IncludeXML  = $TRUE
		   
	   # Set search options
	   $TDT.SensitiveDataSearch.SearchOptions.CheckForeignKeys           = $TRUE
	   $TDT.SensitiveDataSearch.SearchOptions.IgnoreColumnsWithAudits    = $FALSE
	   $TDT.SensitiveDataSearch.SearchOptions.IgnoreRedactedColumns      = $TRUE
	   $TDT.SensitiveDataSearch.SearchOptions.IgnoreEncryptedColumns     = $TRUE
	   $TDT.SensitiveDataSearch.SearchOptions.IgnoreEncryptedTablespaces = $TRUE
	   $TDT.SensitiveDataSearch.SearchOptions.MinimumPercentMatch        = 40
	   $TDT.SensitiveDataSearch.SearchOptions.SampleRecordCount          = 100000
	   
	   # Disable unneeded search rules
	   $TDT.SensitiveDataSearch.SearchRules.DisableRules('1211-1257, 2201-2232')
		   
	   # Enable any needed search rules
	   $TDT.SensitiveDataSearch.SearchRules.EnableRules('1241, 1244-1245, 1252-1253')
		   
	   # Review disabled search rules, if desired
	   $TDT.SensitiveDataSearch.SearchRules.ListDisabled()
	   Read-Host -Prompt "Press Enter to continue"
		   
	   # Review enabled search rules, if desired
	   $TDT.SensitiveDataSearch.SearchRules.ListEnabled()
	   Read-Host -Prompt "Press Enter to continue"
	   
	   # Add a custom user rule
	   $Rule = $TDT.SensitiveDataSearch.SearchRules.Add()
	   $Rule.Name = 'Test Rule'
	   $Rule.RuleType = 0 					# 0 = Search column name, 1 = Search data
	   $Rule.Expression = '\b(?i)test\b'
	   $Rule.Enabled = $TRUE
	   
	   # Execute the search
	   Write-Host "Executing Search..."
	   $TDT.SensitiveDataSearch.Execute()
       }
   }

  }

catch {
	$ErrorMessage  = $_.Exception.Message
	$ErrorLineNum  = $_.InvocationInfo.ScriptLineNumber
	$ErrorPosition = $_.InvocationInfo.OffsetInLine
	$ErrorLine     = $_.InvocationInfo.Line

	Write-Output "************ ERROR ************"
	Write-Output "Line Number/Pos: $ErrorLineNum : $ErrorPosition"
	Write-Output "Error Message  : $ErrorMessage"
	Write-Output "Error Line     : $ErrorLine"
	Write-Output "*******************************"

	throw
}


finally {
	# Run Cleanup Processes
	$TDT.Quit()
}

