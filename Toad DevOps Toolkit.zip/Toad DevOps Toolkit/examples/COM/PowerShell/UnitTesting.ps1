﻿#-------------------------------------------------------------------------------------------------------------------------------
# Copyright (c) 2017 Quest Software
#
# Name: UnitTesting.ps1
#
# Description :  Extracts Unit tests from Source Database.  Imports the first Unit Test found into Target Database.  Runs the 
#                test in the Target Database.
#-------------------------------------------------------------------------------------------------------------------------------


#-----------------------------------------------------------------
#  Important:  Must have Code Tester installed on both Source and 
#  Target DBs and it must be at least v3.2.0.2 
#-----------------------------------------------------------------


$TDT = New-Object -ComObject 'Toad.ToadAutoObject'                                       # Start TDT


try {
     # Make Connections to Source and Target Databases
     $Source = $TDT.Connections.NewConnection('source_user/source_pwd@sourcedb')         # Source DB credentials
     $Target = $TDT.Connections.NewConnection('target_user/target_pwd@targetdb')         # Target DB credentials


     #-----------------------------------------------------------------
     #  Export Unit Tests from Source Database
     #-----------------------------------------------------------------
     $UnitTesting = $TDT.UnitTesting                                                     # Set UnitTesting variable
     $UnitTesting.Connection = $Source                                                   # Set Source Connection


     # Add DB objects - % wildcard accepted, object type not required
     $DBObject = $UnitTesting.UnitTests.DBObjects.Add()                                  # Set DB Object Variable for Add
     $DBObject.ObjectOwner = 'source_schema'                                             # Set Schema Name
     $DBObject.ObjectName  = 'object_name'                                               # Set Object Name


     # Get all unit tests for the object(s)
     $UnitTesting.UnitTests.Refresh()                                                    # Get all Unit Tests From Source
    
     
     # Set Unit Test parameters and Export to File    
     $i = 0                                                                              # Initialize Counter variable
     foreach ($UnitTest in $UnitTesting.UnitTests)                                       # Loop thru all UnitTests
             {$i++                                                                       # Increment Counter variable
              $Filename = "C:\Temp\UnitTesting_$i.xml"                                   # Set Filename (with counter variable)
              $UnitTest.ExportOptions.IncludeSourceCode = $False                         # Set Include SourceCode option to False
              $UnitTest.ExportOptions.IncludeRunResults = $True                          # Set Include Run Results option to True
              $UnitTest.ExportOptions.IncludeTimestamps = $True                          # Set Include Timestamps option to True
              # NOTE! UTF8 Encoding is required else import using CTO GUI will fail
              $UnitTest.Export() | Out-File -FilePath $Filename -Encoding 'UTF8' -Force  # Export Unit Tests to Files   
             } 

   
     #-----------------------------------------------------------------
     #  Import Unit Tests into Target DB
     #  Note:  For Simplicity, only importing the first Test
     #-----------------------------------------------------------------

     # Assign Target connection to UnitTesting
     $UnitTesting.Connection = $Target                                                   # Set Target Connection


     # Read First Unit Testing XML File
     $XMLFile = "C:\Temp\UnitTesting_1.xml"                                              # Set variable to first file created
     $XML = Get-Content $XMLFile -Raw                                                    # Read the file and save contents in $XML variable


     # Run Unit Testing Import
     $result = $UnitTesting.Import($XML)                                                 # Run Unit Test import


     #-----------------------------------------------------------------
     #  Run Unit Tests in Target DB
     #-----------------------------------------------------------------
     $Res = $UnitTesting.UnitTests.Execute()                                             # Run Unit Test in Target database and get result

     if ($Res)                                                                            
        {Write-Output 'Unit Test Status: Passed'}                                        # Send Successful text to screen 
     else 
        {Write-Output 'Unit Test Status: Failed'}                                        # Send Failed text to screen

    }

finally {
         $TDT.Quit()                                                                # Stop TDT
        }
